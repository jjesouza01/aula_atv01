# cypress-actions-pipeline

Projeto de testes E2E com Cypress, com execucao automatica agendada via GitHub Actions.

## Nomes 

Integrantes: Jessica Souza


Como rodar localmente:

npm install e depois
npm test

