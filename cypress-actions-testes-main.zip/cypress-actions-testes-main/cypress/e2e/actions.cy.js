describe('Página Actions - Cypress Example', () => {
  beforeEach(() => {
    cy.visit('https://example.cypress.io/commands/actions')
  })

  it('preenche o campo de e-mail corretamente', () => {
    const email = 'teste.aluno@exemplo.com'

    cy.get('.action-email')
      .type(email)
      .should('have.value', email)
  })

  it('marca uma checkbox e verifica se ela ficou selecionada', () => {
    cy.get('.action-checkboxes input[type="checkbox"]')
      .first()
      .check()
      .should('be.checked')
  })
})